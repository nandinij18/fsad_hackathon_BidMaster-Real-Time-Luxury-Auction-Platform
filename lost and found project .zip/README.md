# Campus Recovery Management System - Full Stack

A comprehensive web application for campus lost item identification and recovery management.

## Tech Stack

### Frontend
- HTML5, CSS3, JavaScript (Vanilla)
- Tailwind CSS
- Font Awesome 6.0
- Inter Font Family
- Glassmorphism UI Design

### Backend
- Java 17
- Spring Boot 3.2.0
- Spring Security with JWT Authentication
- Spring Data JPA
- MySQL Database
- Maven

## Project Structure

```
campus-recovery/
├── backend/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/campus/recovery/
│   │   │   │   ├── config/
│   │   │   │   │   ├── SecurityConfig.java
│   │   │   │   │   ├── ResourceConfig.java
│   │   │   │   │   └── DataInitializer.java
│   │   │   │   ├── controller/
│   │   │   │   │   ├── AuthController.java
│   │   │   │   │   ├── ItemController.java
│   │   │   │   │   └── MessageController.java
│   │   │   │   ├── dto/
│   │   │   │   │   ├── LoginRequest.java
│   │   │   │   │   ├── SignupRequest.java
│   │   │   │   │   ├── JwtResponse.java
│   │   │   │   │   ├── ItemRequest.java
│   │   │   │   │   └── MessageRequest.java
│   │   │   │   ├── entity/
│   │   │   │   │   ├── User.java
│   │   │   │   │   ├── Item.java
│   │   │   │   │   └── Message.java
│   │   │   │   ├── repository/
│   │   │   │   │   ├── UserRepository.java
│   │   │   │   │   ├── ItemRepository.java
│   │   │   │   │   └── MessageRepository.java
│   │   │   │   ├── security/
│   │   │   │   │   ├── JwtTokenProvider.java
│   │   │   │   │   └── AuthTokenFilter.java
│   │   │   │   ├── service/
│   │   │   │   │   ├── AuthService.java
│   │   │   │   │   ├── ItemService.java
│   │   │   │   │   ├── MessageService.java
│   │   │   │   │   └── CustomUserDetailsService.java
│   │   │   │   └── CampusRecoveryApplication.java
│   │   │   └── resources/
│   │   │       └── application.properties
│   │   └── test/
│   └── pom.xml
└── campus-recovery.html (Frontend)
```

## Setup Instructions

### Prerequisites
- Java 17 or higher
- MySQL 8.0 or higher
- Maven 3.6+
- Node.js (optional, for live server)

### Database Setup

1. Install MySQL and start the service
2. Create database (optional - auto-creates on first run):
```sql
CREATE DATABASE campus_recovery_db;
```

3. Update database credentials in `backend/src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/campus_recovery_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=your_password_here
```

### Backend Setup

1. Navigate to backend directory:
```bash
cd backend
```

2. Build the project:
```bash
mvn clean install
```

3. Run the Spring Boot application:
```bash
mvn spring-boot:run
```

The backend will start on `http://localhost:8080`

### Frontend Setup

Simply open `campus-recovery.html` in your browser, or use a live server:

```bash
# Using VS Code Live Server
# Right-click on campus-recovery.html and select "Open with Live Server"
```

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/signup` - User registration

### Items
- `GET /api/items/public/all` - Get all items
- `GET /api/items/public/search?query=` - Search items
- `GET /api/items/public/{id}` - Get item by ID
- `GET /api/items/public/stats` - Get statistics
- `GET /api/items/public/status/{status}` - Get items by status
- `POST /api/items` - Create new item (requires auth)
- `PUT /api/items/{id}` - Update item (requires auth)
- `DELETE /api/items/{id}` - Delete item (requires auth)

### Messages
- `GET /api/messages/item/{itemId}` - Get messages for an item
- `POST /api/messages` - Send message (requires auth)
- `GET /api/messages/conversation/{userId}` - Get conversation history

## Default Credentials

The system initializes with sample data:

**User 1:**
- Mobile: 9876543210
- Password: password123

**User 2:**
- Mobile: 9876543211
- Password: password123

## Features

### Frontend Features
✅ Splash Screen with animated transition
✅ Login/Signup with validation
✅ Selection Screen (Find/Lost item modes)
✅ Dashboard with statistics and recent activity
✅ Recovery Hub with real-time search
✅ Item Reporting with image upload
✅ Item Details Modal
✅ Chat Messenger with auto-reply
✅ Responsive Glassmorphism UI
✅ Smooth animations and transitions

### Backend Features
✅ JWT-based authentication
✅ MySQL database integration
✅ RESTful API design
✅ Image upload handling
✅ Data validation
✅ CORS configuration
✅ Security with Spring Security
✅ Sample data initialization
✅ CRUD operations for items
✅ Message system

## Running the Full Application

1. **Start MySQL Server**
   - Ensure MySQL is running on your system

2. **Start Backend**
   ```bash
   cd backend
   mvn spring-boot:run
   ```

3. **Open Frontend**
   - Open `campus-recovery.html` in your browser
   - The frontend will automatically connect to the backend API

## Configuration

### Backend Configuration
Edit `backend/src/main/resources/application.properties`:
- Database credentials
- JWT secret and expiration
- File upload settings
- Server port

### Frontend Configuration
Edit the `API_BASE_URL` variable in `campus-recovery.html`:
```javascript
const API_BASE_URL = 'http://localhost:8080/api';
```

## Troubleshooting

### Backend Issues
- **Port already in use**: Change `server.port` in application.properties
- **Database connection failed**: Verify MySQL credentials and service status
- **Build failed**: Ensure Java 17+ and Maven are installed

### Frontend Issues
- **CORS errors**: Verify backend CORS configuration
- **API not responding**: Check if backend is running on correct port
- **Images not loading**: Verify upload directory permissions

## Development

### Adding New Features
1. Create entity class in `entity/` package
2. Create repository interface in `repository/` package
3. Create service class in `service/` package
4. Create controller in `controller/` package
5. Update frontend to use new API endpoints

### Database Schema
Tables are auto-created by JPA:
- `users` - User accounts
- `items` - Lost/found items
- `messages` - Chat messages

## License

This project is created for educational purposes.

## Support

For issues or questions, please check the documentation or contact the development team.
