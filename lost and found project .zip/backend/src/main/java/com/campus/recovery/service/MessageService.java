package com.campus.recovery.service;

import com.campus.recovery.dto.MessageRequest;
import com.campus.recovery.entity.Item;
import com.campus.recovery.entity.Message;
import com.campus.recovery.entity.User;
import com.campus.recovery.repository.ItemRepository;
import com.campus.recovery.repository.MessageRepository;
import com.campus.recovery.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageService {
    
    @Autowired
    private MessageRepository messageRepository;
    
    @Autowired
    private ItemRepository itemRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    public List<Message> getMessagesByItem(Long itemId) {
        return messageRepository.findByItemIdOrderByTimestampAsc(itemId);
    }
    
    public Message sendMessage(MessageRequest messageRequest, Long senderId) {
        User sender = userRepository.findById(senderId)
                .orElseThrow(() -> new RuntimeException("Sender not found"));
        
        User receiver = userRepository.findById(messageRequest.getReceiverId())
                .orElseThrow(() -> new RuntimeException("Receiver not found"));
        
        Item item = itemRepository.findById(messageRequest.getItemId())
                .orElseThrow(() -> new RuntimeException("Item not found"));
        
        Message message = new Message();
        message.setItem(item);
        message.setSender(sender);
        message.setReceiver(receiver);
        message.setContent(messageRequest.getContent());
        message.setIsRead(false);
        
        return messageRepository.save(message);
    }
    
    public List<Message> getConversationHistory(Long userId1, Long userId2) {
        return messageRepository.findBySenderIdOrReceiverIdOrderByTimestampDesc(userId1, userId2);
    }
}
