package com.campus.recovery.controller;

import com.campus.recovery.dto.ItemRequest;
import com.campus.recovery.entity.Item;
import com.campus.recovery.service.ItemService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/items")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ItemController {
    
    @Autowired
    private ItemService itemService;
    
    @GetMapping("/public/all")
    public ResponseEntity<List<Item>> getAllItems() {
        return ResponseEntity.ok(itemService.getAllItems());
    }
    
    @GetMapping("/public/search")
    public ResponseEntity<List<Item>> searchItems(@RequestParam String query) {
        return ResponseEntity.ok(itemService.searchItems(query));
    }
    
    @GetMapping("/public/{id}")
    public ResponseEntity<Item> getItemById(@PathVariable Long id) {
        return ResponseEntity.ok(itemService.getItemById(id));
    }
    
    @GetMapping("/public/stats")
    public ResponseEntity<Map<String, Object>> getStatistics() {
        return ResponseEntity.ok(itemService.getStatistics());
    }
    
    @GetMapping("/public/status/{status}")
    public ResponseEntity<List<Item>> getItemsByStatus(@PathVariable String status) {
        return ResponseEntity.ok(itemService.getItemsByStatus(status));
    }
    
    @PostMapping(consumes = {"multipart/form-data"})
    public ResponseEntity<Item> createItem(
            @Valid @RequestPart("item") ItemRequest itemRequest,
            @RequestPart(value = "image", required = false) MultipartFile imageFile,
            Authentication authentication) {
        
        Long userId = getCurrentUserId(authentication);
        Item newItem = itemService.createItem(itemRequest, imageFile, userId);
        return ResponseEntity.ok(newItem);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Item> updateItem(@PathVariable Long id, @Valid @RequestBody ItemRequest itemRequest) {
        return ResponseEntity.ok(itemService.updateItem(id, itemRequest));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteItem(@PathVariable Long id) {
        itemService.deleteItem(id);
        return ResponseEntity.ok("Item deleted successfully");
    }
    
    private Long getCurrentUserId(Authentication authentication) {
        // This is a simplified version - in production, you'd fetch from database
        // using the username from authentication
        return 1L; // Placeholder
    }
}
