package com.campus.recovery.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ItemRequest {
    
    @NotBlank(message = "Item name is required")
    private String name;
    
    @NotBlank(message = "Status is required")
    private String status;
    
    @NotBlank(message = "Location is required")
    private String location;
    
    private String description;
    private String contact;
    private LocalDate date;
}
