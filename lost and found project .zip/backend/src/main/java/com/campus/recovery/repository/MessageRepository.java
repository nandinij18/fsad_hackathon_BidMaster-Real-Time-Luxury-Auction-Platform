package com.campus.recovery.repository;

import com.campus.recovery.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long> {
    List<Message> findByItemIdOrderByTimestampAsc(Long itemId);
    List<Message> findBySenderIdOrReceiverIdOrderByTimestampDesc(Long senderId, Long receiverId);
    Long countByItemId(Long itemId);
}
