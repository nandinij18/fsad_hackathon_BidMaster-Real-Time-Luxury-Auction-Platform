package com.campus.recovery.service;

import com.campus.recovery.dto.JwtResponse;
import com.campus.recovery.dto.LoginRequest;
import com.campus.recovery.dto.SignupRequest;
import com.campus.recovery.entity.User;
import com.campus.recovery.repository.UserRepository;
import com.campus.recovery.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtTokenProvider tokenProvider;
    
    public ResponseEntity<?> login(LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getMobile(), loginRequest.getPassword()));
        
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = tokenProvider.generateToken(authentication);
        
        User user = userRepository.findByMobile(loginRequest.getMobile()).orElseThrow();
        
        JwtResponse response = new JwtResponse(
                jwt,
                user.getId(),
                user.getMobile(),
                user.getStudentId(),
                user.getFullName(),
                user.getRole()
        );
        
        return ResponseEntity.ok(response);
    }
    
    public ResponseEntity<?> signup(SignupRequest signupRequest) {
        if (userRepository.existsByMobile(signupRequest.getMobile())) {
            return ResponseEntity.badRequest().body("Error: Mobile number is already in use!");
        }
        
        if (signupRequest.getStudentId() != null && userRepository.existsByStudentId(signupRequest.getStudentId())) {
            return ResponseEntity.badRequest().body("Error: Student ID is already in use!");
        }
        
        User user = new User();
        user.setMobile(signupRequest.getMobile());
        user.setStudentId(signupRequest.getStudentId());
        user.setPassword(passwordEncoder.encode(signupRequest.getPassword()));
        user.setFullName(signupRequest.getFullName());
        user.setRole("USER");
        user.setEnabled(true);
        
        userRepository.save(user);
        
        return ResponseEntity.ok("User registered successfully!");
    }
}
