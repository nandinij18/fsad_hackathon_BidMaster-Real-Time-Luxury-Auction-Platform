package com.campus.recovery.service;

import com.campus.recovery.dto.ItemRequest;
import com.campus.recovery.entity.Item;
import com.campus.recovery.entity.User;
import com.campus.recovery.repository.ItemRepository;
import com.campus.recovery.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class ItemService {
    
    @Autowired
    private ItemRepository itemRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Value("${app.upload.dir}")
    private String uploadDir;
    
    public List<Item> getAllItems() {
        return itemRepository.findByOrderByCreatedAtDesc();
    }
    
    public List<Item> searchItems(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return getAllItems();
        }
        return itemRepository.searchItems(searchTerm.trim());
    }
    
    public Item getItemById(Long id) {
        return itemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item not found with id: " + id));
    }
    
    public List<Item> getItemsByStatus(String status) {
        return itemRepository.findByStatus(status);
    }
    
    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("lost", itemRepository.countByStatus("Lost"));
        stats.put("found", itemRepository.countByStatus("Found"));
        stats.put("recovered", itemRepository.countByStatus("Recovered"));
        return stats;
    }
    
    public Item createItem(ItemRequest itemRequest, MultipartFile imageFile, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        Item item = new Item();
        item.setName(itemRequest.getName());
        item.setStatus(itemRequest.getStatus());
        item.setLocation(itemRequest.getLocation());
        item.setDescription(itemRequest.getDescription());
        item.setContact(itemRequest.getContact());
        item.setDate(itemRequest.getDate() != null ? itemRequest.getDate() : LocalDate.now());
        item.setReporter(user);
        
        // Handle image upload
        if (imageFile != null && !imageFile.isEmpty()) {
            try {
                String fileName = UUID.randomUUID().toString() + "_" + imageFile.getOriginalFilename();
                Path uploadPath = Paths.get(uploadDir);
                
                if (!Files.exists(uploadPath)) {
                    Files.createDirectories(uploadPath);
                }
                
                Path filePath = uploadPath.resolve(fileName);
                Files.copy(imageFile.getInputStream(), filePath);
                
                item.setImagePath("/uploads/" + fileName);
            } catch (IOException e) {
                throw new RuntimeException("Failed to upload image: " + e.getMessage());
            }
        }
        
        return itemRepository.save(item);
    }
    
    public Item updateItem(Long id, ItemRequest itemRequest) {
        Item item = getItemById(id);
        
        item.setName(itemRequest.getName());
        item.setStatus(itemRequest.getStatus());
        item.setLocation(itemRequest.getLocation());
        item.setDescription(itemRequest.getDescription());
        item.setContact(itemRequest.getContact());
        if (itemRequest.getDate() != null) {
            item.setDate(itemRequest.getDate());
        }
        
        return itemRepository.save(item);
    }
    
    public void deleteItem(Long id) {
        Item item = getItemById(id);
        itemRepository.delete(item);
    }
}
