package com.campus.recovery.config;

import com.campus.recovery.entity.Item;
import com.campus.recovery.entity.User;
import com.campus.recovery.repository.ItemRepository;
import com.campus.recovery.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ItemRepository itemRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Override
    public void run(String... args) {
        // Only initialize if database is empty
        if (userRepository.count() == 0) {
            // Create sample users
            User user1 = new User();
            user1.setMobile("9876543210");
            user1.setStudentId("STU001");
            user1.setPassword(passwordEncoder.encode("password123"));
            user1.setFullName("John Doe");
            user1.setRole("USER");
            user1.setEnabled(true);
            userRepository.save(user1);
            
            User user2 = new User();
            user2.setMobile("9876543211");
            user2.setStudentId("STU002");
            user2.setPassword(passwordEncoder.encode("password123"));
            user2.setFullName("Jane Smith");
            user2.setRole("USER");
            user2.setEnabled(true);
            userRepository.save(user2);
            
            // Create sample items
            Item item1 = new Item();
            item1.setName("Blue Nike Backpack");
            item1.setStatus("Lost");
            item1.setLocation("Library - 2nd Floor");
            item1.setDescription("Blue Nike backpack with laptop compartment. Contains textbooks and a water bottle.");
            item1.setContact("+91 9876543210");
            item1.setDate(LocalDate.of(2026, 4, 7));
            item1.setReporter(user1);
            itemRepository.save(item1);
            
            Item item2 = new Item();
            item2.setName("iPhone 13 Pro");
            item2.setStatus("Found");
            item2.setLocation("Cafeteria");
            item2.setDescription("Black iPhone 13 Pro found on a table near the coffee machine.");
            item2.setContact("+91 9876543211");
            item2.setDate(LocalDate.of(2026, 4, 6));
            item2.setReporter(user2);
            itemRepository.save(item2);
            
            Item item3 = new Item();
            item3.setName("Silver MacBook Charger");
            item3.setStatus("Lost");
            item3.setLocation("Computer Lab");
            item3.setDescription("Original Apple MacBook Pro charger, USB-C type.");
            item3.setContact("+91 9876543210");
            item3.setDate(LocalDate.of(2026, 4, 5));
            item3.setReporter(user1);
            itemRepository.save(item3);
            
            Item item4 = new Item();
            item4.setName("Car Keys with Honda Logo");
            item4.setStatus("Found");
            item4.setLocation("Parking Lot B");
            item4.setDescription("Honda car keys with a red keychain found near the entrance.");
            item4.setContact("+91 9876543211");
            item4.setDate(LocalDate.of(2026, 4, 4));
            item4.setReporter(user2);
            itemRepository.save(item4);
            
            Item item5 = new Item();
            item5.setName("Black Wallet");
            item5.setStatus("Lost");
            item5.setLocation("Sports Complex");
            item5.setDescription("Black leather wallet containing ID card and some cash.");
            item5.setContact("+91 9876543210");
            item5.setDate(LocalDate.of(2026, 4, 3));
            item5.setReporter(user1);
            itemRepository.save(item5);
            
            Item item6 = new Item();
            item6.setName("Calculator - Casio");
            item6.setStatus("Recovered");
            item6.setLocation("Exam Hall");
            item6.setDescription("Scientific calculator successfully returned to owner.");
            item6.setContact("+91 9876543211");
            item6.setDate(LocalDate.of(2026, 4, 2));
            item6.setReporter(user2);
            itemRepository.save(item6);
            
            System.out.println("Sample data initialized successfully!");
        }
    }
}
