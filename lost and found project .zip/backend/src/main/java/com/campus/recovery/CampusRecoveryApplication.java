package com.campus.recovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusRecoveryApplication {
    public static void main(String[] args) {
        SpringApplication.run(CampusRecoveryApplication.class, args);
    }
}
