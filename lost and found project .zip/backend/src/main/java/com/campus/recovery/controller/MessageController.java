package com.campus.recovery.controller;

import com.campus.recovery.dto.MessageRequest;
import com.campus.recovery.entity.Message;
import com.campus.recovery.service.MessageService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
@CrossOrigin(origins = "*", maxAge = 3600)
public class MessageController {
    
    @Autowired
    private MessageService messageService;
    
    @GetMapping("/item/{itemId}")
    public ResponseEntity<List<Message>> getMessagesByItem(@PathVariable Long itemId) {
        return ResponseEntity.ok(messageService.getMessagesByItem(itemId));
    }
    
    @PostMapping
    public ResponseEntity<Message> sendMessage(
            @Valid @RequestBody MessageRequest messageRequest,
            Authentication authentication) {
        
        Long senderId = getCurrentUserId(authentication);
        Message message = messageService.sendMessage(messageRequest, senderId);
        return ResponseEntity.ok(message);
    }
    
    @GetMapping("/conversation/{userId}")
    public ResponseEntity<List<Message>> getConversationHistory(@PathVariable Long userId, Authentication authentication) {
        Long currentUserId = getCurrentUserId(authentication);
        return ResponseEntity.ok(messageService.getConversationHistory(currentUserId, userId));
    }
    
    private Long getCurrentUserId(Authentication authentication) {
        // Placeholder - in production, fetch from database
        return 1L;
    }
}
