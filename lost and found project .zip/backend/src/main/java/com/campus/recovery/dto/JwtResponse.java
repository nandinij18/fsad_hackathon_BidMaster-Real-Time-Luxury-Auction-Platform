package com.campus.recovery.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JwtResponse {
    private String token;
    private Long userId;
    private String mobile;
    private String studentId;
    private String fullName;
    private String role;
}
