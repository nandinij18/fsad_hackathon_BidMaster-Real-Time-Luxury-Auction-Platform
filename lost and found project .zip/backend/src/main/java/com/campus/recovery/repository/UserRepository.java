package com.campus.recovery.repository;

import com.campus.recovery.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByMobile(String mobile);
    Optional<User> findByStudentId(String studentId);
    Boolean existsByMobile(String mobile);
    Boolean existsByStudentId(String studentId);
}
